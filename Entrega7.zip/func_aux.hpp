#include <math.h>
bool compare_float(float a,float b){

   return fabs(a-b) < 0.01f;
}